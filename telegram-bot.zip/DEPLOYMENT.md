# Руководство по развертыванию Telegram бота

## Подготовка проекта

Ваш проект уже готов к развертыванию! Созданы необходимые файлы:
- `Procfile` - указывает Heroku как запускать приложение
- `runtime.txt` - указывает версию Python
- `requirements.txt` - зависимости проекта

## Варианты хостинга

### 1. Heroku (рекомендуется)

#### Шаг 1: Установка Heroku CLI
1. Скачайте и установите [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)
2. Зарегистрируйтесь на [heroku.com](https://heroku.com)

#### Шаг 2: Подготовка проекта
```bash
# Инициализация Git (если еще не сделано)
git init
git add .
git commit -m "Initial commit"

# Создание приложения на Heroku
heroku create your-bot-name
```

#### Шаг 3: Настройка переменных окружения
```bash
# Установка токена бота
heroku config:set BOT_TOKEN=your_actual_bot_token

# Установка ID администратора (опционально)
heroku config:set ADMIN_USER_ID=your_telegram_user_id
```

#### Шаг 4: Развертывание
```bash
git push heroku main
```

#### Шаг 5: Запуск
```bash
heroku ps:scale web=1
```

### 2. Railway

#### Шаг 1: Подготовка
1. Зарегистрируйтесь на [railway.app](https://railway.app)
2. Подключите GitHub репозиторий

#### Шаг 2: Настройка
1. Создайте новый проект
2. Выберите "Deploy from GitHub repo"
3. Выберите ваш репозиторий

#### Шаг 3: Переменные окружения
В настройках проекта добавьте:
- `BOT_TOKEN` = ваш токен бота
- `ADMIN_USER_ID` = ваш Telegram ID (опционально)

### 3. Scalingo (рекомендуется для Европы)

#### Шаг 1: Подготовка
1. Зарегистрируйтесь на [scalingo.com](https://scalingo.com)
2. Установите [Scalingo CLI](https://cli.scalingo.com/)
3. Войдите в аккаунт: `scalingo login`

#### Шаг 2: Создание приложения
```bash
# Создание приложения
scalingo create telegram-bot

# Подключение к GitHub (опционально)
scalingo --app telegram-bot git-setup
```

#### Шаг 3: Переменные окружения
```bash
# Установка токена бота
scalingo --app telegram-bot env-set BOT_TOKEN=your_actual_bot_token

# Установка ID администратора (опционально)
scalingo --app telegram-bot env-set ADMIN_USER_ID=your_telegram_user_id
```

#### Шаг 4: Развертывание
```bash
# Если подключен Git
git push scalingo main

# Или через CLI
scalingo --app telegram-bot deploy
```

#### Шаг 5: Запуск
```bash
scalingo --app telegram-bot scale web:1:S
```

### 4. Render

#### Шаг 1: Подготовка
1. Зарегистрируйтесь на [render.com](https://render.com)
2. Подключите GitHub репозиторий

#### Шаг 2: Создание Web Service
1. Нажмите "New +" → "Web Service"
2. Выберите ваш репозиторий
3. Настройки:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python app.py`
   - **Environment**: Python 3

#### Шаг 3: Переменные окружения
Добавьте в Environment Variables:
- `BOT_TOKEN` = ваш токен бота
- `ADMIN_USER_ID` = ваш Telegram ID (опционально)

## Получение токена бота

1. Найдите [@BotFather](https://t.me/BotFather) в Telegram
2. Отправьте команду `/newbot`
3. Следуйте инструкциям для создания бота
4. Скопируйте полученный токен

## Получение вашего Telegram ID

1. Найдите [@userinfobot](https://t.me/userinfobot) в Telegram
2. Отправьте команду `/start`
3. Скопируйте ваш ID

## Мониторинг и логи

### Heroku
```bash
# Просмотр логов
heroku logs --tail

# Статус приложения
heroku ps
```

### Railway
- Логи доступны в веб-интерфейсе
- Автоматическое перезапуск при сбоях

### Scalingo
```bash
# Просмотр логов
scalingo --app telegram-bot logs

# Статус приложения
scalingo --app telegram-bot status

# Перезапуск приложения
scalingo --app telegram-bot restart
```

### Render
- Логи доступны в веб-интерфейсе
- Автоматическое развертывание при изменениях в Git

## Важные замечания

1. **Бесплатные планы** имеют ограничения по времени работы
2. **Данные** хранятся в файле `bot/data.json` - при перезапуске они сохраняются
3. **Мониторинг** - регулярно проверяйте логи на наличие ошибок
4. **Безопасность** - никогда не коммитьте файл `.env` с реальными токенами

## Решение проблем

### Бот не отвечает
1. Проверьте логи на наличие ошибок
2. Убедитесь, что токен бота правильный
3. Проверьте, что приложение запущено

### Ошибки развертывания
1. Убедитесь, что все файлы добавлены в Git
2. Проверьте синтаксис Python кода
3. Убедитесь, что все зависимости указаны в `requirements.txt`

## Альтернативные варианты

Если бесплатные планы не подходят, рассмотрите:
- **DigitalOcean Droplet** (VPS)
- **AWS EC2**
- **Google Cloud Platform**
- **VPS провайдеры** (Timeweb, REG.RU и др.)

